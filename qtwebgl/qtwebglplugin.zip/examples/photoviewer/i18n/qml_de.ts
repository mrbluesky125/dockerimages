<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>AlbumDelegate</name>
    <message>
        <location filename="../PhotoViewerCore/AlbumDelegate.qml" line="102"/>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="75"/>
        <source>Add</source>
        <translation>Zufügen</translation>
    </message>
    <message>
        <location filename="../main.qml" line="84"/>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <location filename="../main.qml" line="89"/>
        <source>Quit</source>
        <translation>Verlassen</translation>
    </message>
    <message>
        <location filename="../main.qml" line="102"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
</context>
</TS>
